<?php 
	require 'function.php';
	$id = $_GET['id'];
	$tampilkan = query("SELECT * FROM latihancrud WHERE id = $id") [0];

	if (isset($_POST['submit'])){
		if(update($_POST) > 0) {
			echo "
			 data berhasil diupdate
			";
		}

		else {
			echo "data gagal diupdate";
		}
	}
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>update data</title>
</head>
<body>

	<h1>silahkan update data</h1>

	<form action="" method="POST">
		<ul>
			<li>
				<td><input type="hidden" name="id" value="<?= $tampilkan['id'] ?>"></td>
			</li>
			<li>
				<label>nim : </label>
				<input type="text" name="nim" value="<?= $tampilkan['nim'] ?>">
			</li>
			<li>
				<label>nama: </label>
				<input type="text" name="nama" value="<?= $tampilkan['nama'] ?>">
			</li>
			<li>
				<label>tanggal lahir : </label>
				<input type="date" name="tanggalLahir" value="<?= $tampilkan['tanggalLahir'] ?>"></li>
			<li>
				<label>alamat: </label>
				<input type="text" name="alamat" value="<?= $tampilkan['alamat'] ?>">
			</li>
			<li><label>email : </label><input type="text" name="email" value="<?= $tampilkan['email'] ?>"></li>
		</ul>
		<button type="submit" name="submit">submit</button>
	</form>

	<a href="index.php"> kembali</a>

</body>
</html>