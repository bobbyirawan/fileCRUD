<?php 
	require "function.php";
	
	if (isset($_POST['submit'])) {
		if (tambah($_POST) > 0) {
			echo "
				<script>
					alert('data berhasil ditambahkan');
					document.location.href ='index.php';
				</script>
			";
		}
		else {
			echo "data gagal ditambahkan";
		}
	}
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>tambah data</title>
</head>
<body>

	<h1>silahkan tambahkan data</h1>

	<form action="" method="POST">
		<ul>
			<li>
				<label>nim : </label>
				<input type="text" name="nim">
			</li>
			<li>
				<label>nama: </label>
				<input type="text" name="nama">
			</li>
			<li>
				<label>tanggal lahir : </label>
				<input type="date" name="tanggalLahir"></li>
			<li>
				<label>alamat: </label>
				<input type="text" name="alamat">
			</li>
			<li><label>email : </label><input type="text" name="email"></li>
		</ul>
		<button type="submit" name="submit">submit</button>
	</form>

</body>
</html>