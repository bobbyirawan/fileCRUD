<?php 
	require "function.php";
	$mahasiswa = query('SELECT * FROM  latihancrud');


	$r = 1;
 ?>


<!DOCTYPE html>
<html>
<head>
	<title>latihan crud</title>
</head>
<body>

	<h1>Data mahasiswa</h1>
	<a href="tambah.php">Tambah Data</a>
	<table border="1">
		<thead>
			<th>no</th>
			<th>action</th>
			<th>nim</th>
			<th>nama</th>
			<th>tanggal lahir</th>
			<th>alamat</th>
			<th>email</th>
		</thead>
		<tbody>
			<?php foreach ($mahasiswa as $value) : ?>
			<tr>
				<td><?php echo $r; $r++; ?></td>
				<td>
					<a href="update.php?id=<?=$value['id'];?>">update</a> | <a href="delete.php?id=<?= $value['id']; ?>">delete</a>
				</td>
				<td><?= $value['nim']; ?></td>
				<td><?= $value['nama']; ?></td>
				<td><?= $value['tanggalLahir']; ?></td>
				<td><?= $value['alamat']; ?></td>
				<td><?= $value['email']; ?></td>
			</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</body>
</html>