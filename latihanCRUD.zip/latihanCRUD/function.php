<?php 
$connect = mysqli_connect('localhost', 'root', '','latihanphp');

	function query($fetch){
		global $connect;
		$result = mysqli_query($connect, $fetch );

		 $array = [];
			while ($row = mysqli_fetch_assoc($result)) {
				$array[] = $row;
			}
		return $array;
	}

	function tambah($fetch) {
		global $connect;
		$nim = $fetch['nim'];
		$nama = $fetch['nama'];
		$born = $fetch['tanggalLahir'];
		$alamat = $fetch['alamat'];
		$email =   $fetch['email'];

		$result = "INSERT INTO latihancrud 
				VALUES ('', '$nim', '$nama', '$born', '$alamat',
				 '$email')";
		mysqli_query($connect, $result);
		return mysqli_affected_rows($connect);
	}

	function update($fetch) {
		global $connect;
		$id = $fetch['id'];
		$nim = $fetch['nim'];
		$nama = $fetch['nama'];
		$born = $fetch['tanggalLahir'];
		$alamat = $fetch['alamat'];
		$email =   $fetch['email'];

		$result = "UPDATE  latihancrud SET 
					nim = '$nim',
					nama = '$nama',
					tanggalLahir = '$born',
					alamat = '$alamat',
					email = '$email'
					WHERE id = '$id'"; mysqli_query($connect, $result); return mysqli_affected_rows($connect); } function delete($fetch) {global $connect; $hapus = "DELETE FROM latihancrud WHERE id = $fetch"; mysqli_query($connect, $hapus); return mysqli_affected_rows($connect); } ?>